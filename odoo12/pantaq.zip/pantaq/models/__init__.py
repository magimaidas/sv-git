# -*- coding: utf-8 -*-

from . import config
from . import crm
from . import purchase
from . import internal_quotation
from . import terms_condition
from . import sale
from . import account_invoice
from . import product_template