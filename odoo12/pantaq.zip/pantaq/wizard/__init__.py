# -*- coding: utf-8 -*-

from . import wizard
from . import wizard_response_confirmation